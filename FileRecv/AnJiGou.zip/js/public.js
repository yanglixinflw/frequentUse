// JavaScript Document
//头部搜索点击换值
$(".search-bar .select .tops").click(function(){
    $(this).siblings(".bots").slideToggle();
});
$(".search-bar .select a").click(function(){
    $(this).parents(".select").find(".tops span").text($(this).text());
    $(this).parents(".bots").slideUp();
    $("#search_cate").val($(this).text());
});

//滚动时出现浮动头部
$(window).on("scroll",function(){
    if($(window).scrollTop() > 100){
        $(".fixed-header").css({
            "top": "0"
        })
    }else{
        $(".fixed-header").css({
            "top": "-70px"
        })
    }
});

//弹出视频播放
function showVideo(obj){
    var html = '<video controls autoplay><source src="' + $(obj).attr("data-src") +'" type="video/mp4"></source></video>';
    layer.open({
        type: 1,
        title: false,
        closeBtn: 1,
        shadeClose: true,
        skin: 'video-layer',
        area: ['auto','auto'],
        content: html,
    });
};


//产品相册
var thumbIndex = 0;//当前选中小图index
var thumbLength = $(".goods-thumbs .items").find(".item").length;//小图个数
renderIndex();//页面加载先初始化下标
//向前
$(".goods-thumb-prev").click(function(){
    if(thumbIndex > 0){
        thumbIndex--;
        renderIndex();
        $(".goods-thumbs .items").find(".active").click();
    };
    if(thumbLength > 5 && thumbIndex == 4){
        $(".goods-thumbs .items").animate({
            left:'0',
        });
    }else if(thumbLength > 5 && thumbIndex == 9){
        $(".goods-thumbs .items").animate({
            left:'-395px',
        });
    };
});
//向后
$(".goods-thumb-next").click(function(){
    if(thumbIndex < thumbLength-1){
        thumbIndex++;
        renderIndex();
        $(".goods-thumbs .items").find(".active").click();
    };
    if(thumbLength > 5 && thumbIndex == 5){
        $(".goods-thumbs .items").animate({
            left:'-395px',
        });
    }else if(thumbLength > 5 && thumbIndex == 10){
        $(".goods-thumbs .items").animate({
            left:'-790px',
        });
    };
});
//重置当前高亮
function renderIndex(){
    $(".goods-thumbs .items").find(".item").eq(thumbIndex).addClass("active");
    $(".goods-thumbs .items").find(".item").eq(thumbIndex).siblings().removeClass("active");
};
//点击查看大图
function showBig(obj){
    if($(obj).attr("data-type") == 'image'){
        var html = '<img src="'+ $(obj).attr("data-url") +'" alt="">';
    }else if($(obj).attr("data-type") == 'video'){
        var html = '<video autoplay controls muted="true"><source src="'+ $(obj).attr("data-url") +'" type="video/mp4"></source></video>';
    };
    $("#bigimg").html(html);
    thumbIndex = $(obj).index();
    renderIndex();
};


// // 地址选择
// $(".address-list li").click(function () {
//     $(".address-list li").removeClass("active");
//     $(this).addClass("active");
// });








