// JavaScript Document
// 头部导航
function scroll_fixed() {
	//var top1 = $("#scroll_fixed").offset().top;
	$(window).scroll(function() {
		var win_top = $(this).scrollTop();
		//var top = $(".header .top").offset().top;
		if (win_top >= 10) {
			$(".header").addClass("header-active");
		}
		if (win_top < 10) {
			$(".header").removeClass("header-active");
		}
	})
};
setTimeout(scroll_fixed, 1);
// 底部微信分享
function share(){
	$('#share-2').share({
		sites: ['wechat','qq']
	});
};
share();
// 头部二级导航
$(".nav li").hover(function(){
	$(this).find(".second").slideToggle();
})