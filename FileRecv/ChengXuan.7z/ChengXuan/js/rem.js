(function(doc, win) {
	var docEl = doc.documentElement,
		resizeEvt = 'orientationchange' in window ? 'orientationchange' : 'resize',
		recalc = function() {
			var clientWidth = docEl.clientWidth;
			if(!clientWidth) return;
			if(clientWidth >= 750) {
				var windowwidth = parseInt($(window).width());
				var windowheight = parseInt($(window).height());
				var realwidth = parseInt(750 / 1334 * windowheight);
                var size = 100 * (realwidth / 750);
                $('html').css('font-size', size + 'px');
				$('body').width(realwidth);
				setTimeout(function(){
					$("body").css({
						"visibility": "visible"
					});
				},100);
				
			} else {
				docEl.style.fontSize = 100 * (clientWidth / 750) + 'px';
				setTimeout(function(){
					$("body").css({
						"visibility": "visible"
					});
				},100);
			}
		};
	if(!doc.addEventListener) return;
	win.addEventListener(resizeEvt, recalc, false);
	doc.addEventListener('DOMContentLoaded', recalc, false);
})(document, window);